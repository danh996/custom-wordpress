<?php return array('dependencies' => array('wp-block-editor', 'wp-blocks', 'wp-element', 'wp-i18n', 'wp-editor', ), 'version' => 'a35cc1c098b69994c9c6d6dc1416bb90');
